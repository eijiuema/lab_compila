/*
*	Anderson Pinheiro Garrote
*	Gabriel Eiji Uema Martin
*/
package ast;
import java.util.*;

public class SemicolonStat extends Stat{

    public void genJava(PW pw){
        //...
    }
    public void genC(PW pw){
        //...
    }
    
}