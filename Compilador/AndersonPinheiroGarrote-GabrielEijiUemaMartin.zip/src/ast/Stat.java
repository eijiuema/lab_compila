/*
*	Anderson Pinheiro Garrote
*	Gabriel Eiji Uema Martin
*/
package ast;

abstract public class Stat {

	//abstract public void genC(PW pw);

}
