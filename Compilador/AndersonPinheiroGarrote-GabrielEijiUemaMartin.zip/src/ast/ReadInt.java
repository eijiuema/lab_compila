/*
*	Anderson Pinheiro Garrote
*	Gabriel Eiji Uema Martin
*/
package ast;

public class ReadInt extends ReadExpr {

    public void genJava(PW pw){
        
        
    }

    public Type getType() {
        return Type.intType;
    }
}